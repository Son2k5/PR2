package Pr2_Tutorial1_Activity1;

public class problem_1 {
    public static void main(String[] args) {
        printD();
        printJ();
        printE();
    }

    public static void printD() {
        System.out.println("*******  ");
        System.out.println("*      * ");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*      * ");
        System.out.println("*******  ");
        System.out.println();
    }

    public static void printJ() {
        System.out.println(" ******* ");
        System.out.println("     *   ");
        System.out.println("     *   ");
        System.out.println("     *   ");
        System.out.println("     *   ");
        System.out.println("*    *   ");
        System.out.println("*    *   ");
        System.out.println(" *****   ");
        System.out.println();
    }

    public static void printE() {
        System.out.println("*******  ");
        System.out.println("*        ");
        System.out.println("*        ");
        System.out.println("*******  ");
        System.out.println("*        ");
        System.out.println("*        ");
        System.out.println("*******  ");
        System.out.println();
    }
}
