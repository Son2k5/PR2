package PR2_Tutorial3_Activity2;

public class Activity2 {
    public static void main(String[] args) {
        Product product = new Product();
        product.input();
        product.display();
    }
}
